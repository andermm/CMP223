#ifdef __cplusplus
extern "C"
{
#endif
#include <stddef.h>

extern void
POMP2_Init_reg_1m6la4etldzk5_1();

void
POMP2_Init_regions()
{
    POMP2_Init_reg_1m6la4etldzk5_1();
}

size_t
POMP2_Get_num_regions()
{
    return 1;
}

#ifdef __cplusplus
}
#endif
