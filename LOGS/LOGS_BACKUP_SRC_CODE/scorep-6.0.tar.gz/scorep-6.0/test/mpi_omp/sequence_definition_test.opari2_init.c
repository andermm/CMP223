#include <config.h>
#ifdef __cplusplus
extern "C"
{
#endif
#include <stddef.h>

extern void
POMP2_Init_reg_yzn8k655ma1pr3_1();

void
POMP2_Init_regions()
{
    POMP2_Init_reg_yzn8k655ma1pr3_1();
}

size_t
POMP2_Get_num_regions()
{
    return 1;
}


void
POMP2_USER_Init_regions()
{
}

size_t
POMP2_USER_Get_num_regions()
{
    return 0;
}

#ifdef __cplusplus
}
#endif
