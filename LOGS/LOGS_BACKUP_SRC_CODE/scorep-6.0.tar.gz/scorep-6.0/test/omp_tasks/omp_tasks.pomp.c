#ifdef __cplusplus
extern "C"
{
#endif
#include <stddef.h>

extern void
POMP2_Init_reg_jl6l9ddtlx35j_4();

void
POMP2_Init_regions()
{
    POMP2_Init_reg_jl6l9ddtlx35j_4();
}

size_t
POMP2_Get_num_regions()
{
    return 4;
}

#ifdef __cplusplus
}
#endif
