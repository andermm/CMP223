#include <config.h>

#ifdef __cplusplus
extern "C"
{
#endif
#include <stddef.h>

extern void
FORTRAN_MANGLED( pomp2_init_reg_sjwin65ixa08_3 )();

void
POMP2_Init_regions()
{
    FORTRAN_MANGLED( pomp2_init_reg_sjwin65ixa08_3 )();
}

size_t
POMP2_Get_num_regions()
{
    return 4;
}

#ifdef __cplusplus
}
#endif
