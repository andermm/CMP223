#ifdef __cplusplus
extern "C"
{
#endif

int
fn_21_filter_test( void );

#ifdef __cplusplus
};
#endif
