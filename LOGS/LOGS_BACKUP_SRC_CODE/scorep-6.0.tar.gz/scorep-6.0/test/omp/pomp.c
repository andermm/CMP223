#ifdef __cplusplus
extern "C"
{
#endif
#include <stddef.h>
#include <stdio.h>

extern void
POMP2_Init_reg_4k6lsdctlab37_1();

void
POMP2_Init_regions()
{
    POMP2_Init_reg_4k6lsdctlab37_1();
}

size_t
POMP2_Get_num_regions()
{
    return 1;
}

#ifdef __cplusplus
}
#endif
